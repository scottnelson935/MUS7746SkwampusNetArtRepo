module.exports = {

	rules: {
		'header/header': 'off'
	}

};
