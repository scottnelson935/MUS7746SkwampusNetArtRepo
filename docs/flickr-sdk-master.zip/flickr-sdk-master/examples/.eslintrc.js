module.exports = {

	env: {
		es6: true
	},

	rules: {
		'no-console': 'off',
		'header/header': 'off'
	}

};
