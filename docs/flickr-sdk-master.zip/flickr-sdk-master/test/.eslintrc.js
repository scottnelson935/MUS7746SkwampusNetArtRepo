module.exports = {

	env: {
		mocha: true
	},

	rules: {
		'header/header': 'off'
	}

};
